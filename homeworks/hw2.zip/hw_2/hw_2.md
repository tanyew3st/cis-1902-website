# Homework 2

This homework is going to be creating a special type of file and folder called and RFile and RFolder. These are just traditional files and folder with the difference that an RFile can be added together easily. Thus, you can load in from file (or randomly generate) an RFile, add them together, and save them back out to our file system. This makes for easy content concatenation and an overall nice experience. The RFolder is a container mean to essentially be an iterable holder for the RFiles.  

### RFile Features

- **Adding Files Together**:
RFiles support the easy functionality of adding files together. Since we are implementing the _ _ add _ _, you will be able to simply put two files together using the + sign. Make sure that you follow the instructions on combining files! You may find the os module helpful.

- **Only Storing Necessary Information**:
The RFiles only store the filename initially and load in content only if necessary. 

- **Saving the File**:
The RFile lets you save the file back to the disk, even after a series of combinations.

### RFile Creation
- **Pathname/Content Initialization**: One of the core features of the `RFile` class is its flexibility in initialization. You can create an `RFile` instance by either specifying a pathname to an existing file on the disk or by directly providing content as a string. This dual approach allows you to work with both physical files and in-memory data seamlessly. For this, we want to store the file and only load in the content when we need to combine or do operations on the files. (Think about what data you may want to store)

- **Random Content Generation**: Additionally, `RFile` can generate instances with random content. This feature is intended to demonstrate the power of static methods and to provide a tool for creating test data. Try to use either list comprehensions or some of the string characteristics we talked about. 

## RFolder Creation

- **List of Files**:
You can either create the RFolder with a list of files or nothing! I.e. you can initialize it with no data and add RFiles after the fact. RFolders are intended to be an easy and light storage of RFile objects!

## Advanced Python Features in Use

### Context Managers
- Utilized in the `DualFileOpener` class, context managers will simplify the process of managing resources such as file handles. By ensuring that files are properly closed after operations, regardless of whether an error occurs, you'll be implementing safer and cleaner file operations. If you understand the standard file opening, this shouldn't be that different!

### Iterators
- The `RFolder` class will act as a collection of `RFile` instances and must be iterable. This means implementing the `__iter__` and `__next__` methods to allow users to iterate over the collection of files, enhancing usability and enabling Pythonic operations like loops over `RFolder` instances.

### Decorators
- The `@time_ms` decorator is a specific example, used to measure and print the execution time of methods. This will not only help in optimizing your code but also serve as a practical application of decorators to augment the functionality of existing methods. Please follow the string formatting for full points!

This assignment is meant to help you practice using some advanced Python features in a more real-world scenario. 