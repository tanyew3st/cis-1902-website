import os
from rfile import RFile, DualFileOpener
from rfolder import RFolder
import io
import sys

def create_sample_files():
    if os.path.exists("sample1.txt"):
        os.remove("sample1.txt")
    if os.path.exists("sample2.txt"):
        os.remove("sample2.txt")
    with open("sample1.txt", "w") as f:
        f.write("Content of sample1.")
    with open("sample2.txt", "w") as f:
        f.write("Content of sample2.")
    print("Sample files created.")

def test_rfile_initialization():
    # Test initialization with filename
    rfile = RFile(filename="sample1.txt")
    assert os.path.exists(rfile.filename), "RFile initialization with filename failed."
    print("RFile initialization with filename: PASS")

    # Test initialization with content
    content = "Direct content"
    rfile = RFile(content=content)
    assert rfile.content == content, "RFile initialization with content failed."
    print("RFile initialization with content: PASS")

def test_add_exceed_memory_limit():
    RFile.set_memory_limit(10)  # Set a low memory limit for testing
    try:
        _ = RFile(content="12345") + RFile(content="67890abc")
        print("test_add_exceed_memory_limit: FAIL - Expected to raise ValueError due to memory limit.")
    except ValueError:
        print("test_add_exceed_memory_limit: PASS")
    except Exception as e:
        print(f"test_add_exceed_memory_limit: FAIL - Unexpected exception: {e}")
    finally:
        RFile.set_memory_limit(1024)

def test_add_content():
    # Adjusting filenames to match the created sample files
    file1 = RFile(filename="sample1.txt")
    file2 = RFile(filename="sample2.txt")
    combined_file = file1 + file2
    expected_content = "Content of sample1.Content of sample2."
    if combined_file.content == expected_content:
        print("test_add_content: PASS")
    else:
        print(f"test_add_content: FAIL - Content should be '{expected_content}' but was '{combined_file.content}'.")

def test_time_ms_decorator():
    # Redirect stdout to capture the output of the decorator
    captured_output = io.StringIO()  # Create StringIO object to capture output
    sys.stdout = captured_output  # Redirect stdout to the StringIO object
    _ = RFile(content="12345") + RFile(content="67890abc")
    sys.stdout = sys.__stdout__
    output = captured_output.getvalue()
    if "Execution time:" in output and "ms" in output:
        print("test_time_ms_decorator: PASS")
    else:
        print("test_time_ms_decorator: FAIL - The decorator did not print the expected output.")

def test_add_with_one_filename():
    # Using a sample file and content without an associated file
    file1 = RFile(filename="sample1.txt")
    file2 = RFile(content=" and some extra content")
    combined_file = file1 + file2
    # Expecting the combined content to be the sum of file1's content and file2's content
    expected_content = "Content of sample1. and some extra content"
    if combined_file.content == expected_content:
        print("test_add_with_one_filename: PASS")
    else:
        print("test_add_with_one_filename: FAIL - Combined content did not match expected.")

def test_add_with_no_filenames():
    # Resetting counter to ensure predictable combined filename
    RFile.counter = 0
    file1 = RFile(content="No filename")
    file2 = RFile(content=" here")
    combined_file = file1 + file2
    combined_file_2 = file1 + file2
    # The combined file should adopt a generated filename based on the counter
    if combined_file.filename == "combined_0.txt" and combined_file_2.filename == "combined_1.txt":
        print("test_add_with_no_filenames: PASS")
    else:
        print(f"test_add_with_no_filenames: FAIL - Filename was '{combined_file.filename}', expected 'combined_1.txt'.")

def test_rfile_memory_limit():
    RFile.set_memory_limit(1024)  # Setting a new memory limit
    try:
        RFile.generate_random_content(2048)  # Attempt to generate content exceeding the limit
        print("test_rfile_memory_limit: FAIL - Memory limit test failed to raise an exception.")
    except ValueError:
        print("Memory limit enforcement: PASS")
    except Exception as e:
        print(f"test_rfile_memory_limit: FAIL - Unexpected exception: {e}")

def test_rfile_random_content():
    # Test random content generation
    rfile = RFile.generate_random_content(100)
    assert len(rfile.content) <= 100, "RFile random content generation failed."
    assert all([ord('a') <= ord(c) <= ord('z') for c in rfile.content]), "RFile random content generation failed."
    print("Random content generation: PASS")

def test_dual_file_opener():
    # Test DualFileOpener context manager
    with DualFileOpener("sample1.txt", "sample2.txt") as (f1, f2):
        content1 = f1.read()
        content2 = f2.read()
        assert content1 == "Content of sample1.", "DualFileOpener failed for file 1."
        assert content2 == "Content of sample2.", "DualFileOpener failed for file 2."
    print("DualFileOpener: PASS")

def test_rfolder():
    # Test RFolder functionality
    rfolder = RFolder()
    rfolder.add_file(RFile(filename="sample1.txt"))
    rfolder.add_file(RFile(content="Direct content"))
    combined_file = rfolder.combine_all("output.txt")
    assert combined_file.content == "Content of sample1.Direct content", "RFolder combine_all failed."
    print("RFolder functionality: PASS")

def main():
    create_sample_files()
    test_rfile_initialization()
    test_add_content()
    test_add_exceed_memory_limit()
    test_add_with_one_filename()
    test_add_with_no_filenames()
    test_time_ms_decorator()
    test_rfile_memory_limit()
    test_rfile_random_content()
    test_dual_file_opener()
    test_rfolder()

if __name__ == "__main__":
    main()