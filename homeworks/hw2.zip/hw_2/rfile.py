import os
import time
import random

"""

TODO: Supplementary questions for the homework
Number of hours: 
Favorite thing about the homework:
Least favorite thing about the homework: 

"""


class DualFileOpener:
    """
    A context manager for opening two files simultaneously,
    facilitating operations that require concurrent access to two files.
    """

    def __init__(self, filename1, filename2, mode="r"):
        """
        Initializes the context manager with filenames and a mode.

        Parameters:
        - filename1: First file's path.
        - filename2: Second file's path.
        - Be sure to check that both files exist before opening them. Otherwise
            raise a FileNotFoundError.
        - mode: Mode for opening the files ('r' for read, 'w' for write, etc.).
        """
        raise NotImplementedError

    def __enter__(self):
        """
        Opens both files in the specified mode and returns the file objects.

        Returns:
        A tuple containing the file objects for both files.
        """
        raise NotImplementedError

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Ensures both files are closed when exiting the context.
        """
        raise NotImplementedError


class RFile:
    """
    Represents a file that can be loaded from disk or created with specific content.
    """

    memory_limit = 1024  # Max content length in characters.
    counter = 0  # Counter for generating default filenames.

    def __init__(self, filename=None, content=None):
        """
        Initializes an RFile with either a filename or content.

        - Raises ValueError if neither content nor filename are provided.
        - If you provide only the filename, it must exist in the file system.
            Otherwise, raise FileNotFoundError.
        - If content is provided, it initializes the file with this content,
          raises ValueError if the content exceeds the memory limit.

        Parameters:
        - filename (optional): The file's name to load.
        - content (optional): The content to initialize the file with.
        """
        raise NotImplementedError

    @property
    def content(self):
        """
        Accesses the file's content, loading it if necessary.
        - Notice this is why we have the @property: it ensures that
            we don't let users just access empty content is the filename
            exists but the content hasn't been loaded yet.

        Returns:
        - The file's content.
        """
        raise NotImplementedError

    @classmethod
    def set_memory_limit(cls, size):
        """
        Adjusts the memory limit for RFile instances.
        - Ensure the memory limit is a positive integer.

        Parameters:
        - size: New memory limit in characters.
        """
        raise NotImplementedError

    @staticmethod
    def generate_random_content(length):
        """
        Generates an RFile instance with random content, adhering to the memory limit.

        - Throws ValueError if the requested content length exceeds the memory limit.
        - Uses characters 'a' to 'z' and spaces to generate content.
        - Picks some random value between 1 and length for the generated content length

        Parameters:
        - length: Desired content length.

        Returns:
        An RFile instance with the generated content.
        """
        raise NotImplementedError

    def time_ms(func):
        """
        A decorator that measures the execution time of the decorated function in milliseconds.
        This needs to be printed in the format "Execution time: {time} ms". where time is
        rounded to 3 decimal places.
        """
        raise NotImplementedError

    @time_ms
    def __add__(self, other):
        """
        Combines content of this RFile with another, producing a new RFile instance.

        - If both filenames exist, the new file's name should be a concatenation of the two names.
        - If only one filename exists, the new file uses that filename with '_2' appended
        - If neither filename exists, uses 'combined_{counter}' as the new filename, and increments counter.
        - Be sure to append .txt if it doesn't exist (we are only working with text files)

        Parameters:
        - other: The other RFile to combine with.

        Returns:
        A new RFile instance with combined content.

        Raises:
        - ValueError if combining exceeds memory limit.
        """
        raise NotImplementedError

    @time_ms
    def save(self):
        """
        Saves the RFile's content to a specified file path.

        - Generates a filename if not initially provided using the format 'file_{counter}.txt' and
            increments the counter as well.

        Raises:
        - IOError if saving fails.
        """
        raise NotImplementedError
