from functools import reduce
from rfile import RFile

class RFolder:
    """
    Represents a folder for managing a collection of RFile instances. It allows adding files,
    iterating over them, and combining their contents into a single RFile.
    """
    def __init__(self, initial_files=None):
        """
        Initializes an RFolder possibly with an initial list of RFile instances.
        
        Parameters:
        - initial_files (list of RFile, optional): Initial files to include in the folder.
        """
        self.files = initial_files if initial_files is not None else []
        self.current = 0 # Counter for the iterator

    def add_file(self, rfile):
        """
        Adds an RFile instance to the folder.
        
        Parameters:
        - rfile (RFile): The RFile instance to add.
        """
        raise NotImplementedError("Add RFile instance to the folder.")

    def __iter__(self):
        """
        Resets the internal counter and returns the iterator object.
        """
        raise NotImplementedError("Reset counter and return self as an iterator.")

    def __next__(self):
        """
        Advances to the next RFile in the folder and returns it.
        
        Raises StopIteration when there are no more files to iterate over.
        """
        raise NotImplementedError("Return the next RFile or raise StopIteration.")

    def combine_all(self, output_filename):
        """
        Combines the content of all RFile instances in the folder into a single RFile.
        Must have output_filename, and you must use 'functools.reduce'
        
        Parameters:
        - output_filename (str): The filename for the combined output RFile.
        """
        raise NotImplementedError("Combine all RFile contents and return a new RFile with the specified filename.")
