# Homework 3

## Overview

This homework is designed to get you acquainted with Python imports, unit testing, implementation of class methods, and the development pipeline. 

### Part 1: Fixing Import Issues (15 pts)

Currently, running `main.py` in the terminal as usual results in an error due to improper imports. Resolve this by fixing the way imports are handled in one of the nested files within the project. There is a single line of code to be deleted that would resolve this issue, but you can also change imports if you would like.

Both solutions are acceptable.

**How did you fix this? A: ________**

**(EC) What are three *other* ways we could have fixed this? A: ________**

### Part 2: Running Unit Tests on `car.py` (30 pts)

Attempt to run `test_car.py` to execute unit tests. There are two errors in `car.py` preventing the test cases from passing. Correct these errors and rerun the tests to ensure they pass successfully.

Be sure to run this using the following command (depending on the directory):

```bash
python -m unittest tests/test_car.py
python -m unittest test_car.py
```

### Part 3: Implementing Methods in `employee.py` (30 pts)

Several methods in `employee.py` are unimplemented. Your task is to implement these methods and accurately add type annotations (e.g., `:str`, `:int`) to the method signatures. Try to implement each method as pythonically as possible!

### Part 4: Writing Test Cases for the `Employee` Class (25 pts)

Write test cases for the methods you implemented in Part 3. Ensure your tests cover both successful operations and scenarios that should raise errors. We only ask that each method has **two** test cases to be considered complete, but make sure these tests are distinct and non-overlapping. If necessary, you may add auxiliary methods in the `Employee` class to facilitate testing.

The objective is not to spend excessive time on this task but to familiarize yourself with navigating the development process.

## Submission Guidelines

Submit the following files upon completion:

- `car.py`
- `test_employee.py`
- `employee.py`
- `Readme.md` (containing explanation for how you fixed Part 1)

Ensure your submission follows the instructions for each part.
