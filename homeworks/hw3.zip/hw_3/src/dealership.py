class Dealership:
    def __init__(self, name: str, employees: list, inventory: list):
        self.name = name
        self.employees = employees
        self.sales = []
        self.inventory = inventory

    def get_employee(self, employee_id: int):
        for employee in self.employees:
            if employee.employee_id == employee_id:
                return employee
        return None

    def get_inventory(self):
        return self.inventory

    def get_sales(self):
        return self.sales

    def get_employee_sales(self, employee_id: int):
        employee = self.get_employee(employee_id)
        if employee is None:
            return None
        return [sale for sale in self.sales if sale.employee == employee]
