from vehicles import *
from people import *
from dealership import *

if __name__ == "__main__":
    dealership = Dealership("My Dealership", [], [])
    my_car = Car("Toyota", "Corolla", 2020)
