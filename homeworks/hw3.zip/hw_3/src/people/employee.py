class Employee:
    def __init__(self, name: str, employee_id: int):
        self.name = name
        self.employee_id = employee_id
        self.tasks = []

    # hint you can type *arg parameter should be typed as if it was a single param
    def get_average_commission(self, *sales):
        """
        Weighted average of the commission per sale.

        :param sales: each sale is tuple whose first element is the number of sales,
            second element is the commission per sale, both will be integers.
        :return: The average commission (float).
        :raises ValueError: If any of the count or dollar value contain negative numbers

        For example: get_average_commission((5, 1000), (5, 500)) -> 750.0
        """
        raise NotImplementedError

    @staticmethod
    def convert_to_employee(employee_dict_list):
        """
        Convert a list of dictionaries to a list of employees

        This should return an Employee object for each dictionary in the list.

        :param employee_dict_list: A list of dictionaries where each dictionary contains the name and employee_id of an employee.
        :return: A list of Employee objects.
        :raises ValueError: If the dictionary does not contain the name and employee_id keys for EVERY element.

        For example, convert_to_employee([{"name": "Alice", "employee_id": 1}, {"name": "Bob", "employee_id": 2}])
            -> [Employee(name='Alice', employee_id=1), Employee(name='Bob', employee_id=2)]
        """
        raise NotImplementedError

    def add_task(self, task):
        """
        Add a task to the employee's list of tasks.

        :param task: The task to add. This will always be a string
        :raises ValueError: If the task is already in the list of tasks.

        no return value
        """
        raise NotImplementedError

    def complete_task(self, task):
        """
        Remove a task from the employee's list of tasks.

        :param task: The task to remove. This will always be a string.
        :raises ValueError: If the task is not in the list of tasks.

        no return value
        """
        raise NotImplementedError

    # hint: for the typing use Iterator[str] as the return value
    def get_tasks_generator(self):
        """
        A generator that yields the tasks of the employee.

        :return: A generator that yields the tasks of the employee one by one.
            refer back to earlier lectures for guidance on generators.
        """
        raise NotImplementedError
