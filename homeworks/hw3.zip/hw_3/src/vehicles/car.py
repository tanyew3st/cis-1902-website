from typing import List, Optional


class Car:
    def __init__(
        self, make: str, model: str, year: int, features: Optional[List[str]] = []
    ):
        self.make = make
        self.model = model
        self.year = year
        self.mileage = 0
        self.features = features

    def drive(self, miles: int):
        if miles < 0:
            raise ValueError("Miles driven cannot be negative.")
        self.mileage += miles

    def add_features(self, new_feature: str):
        self.features += new_feature
