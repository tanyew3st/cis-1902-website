from .car import Car


class Van(Car):
    def __init__(self, make: str, model: str, year: int, capacity: int):
        super().__init__(make, model, year)
        self.capacity = capacity

    def add_capacity(self, capacity: int):
        self.capacity += capacity

    def remove_capacity(self, capacity: int):
        self.capacity -= capacity
