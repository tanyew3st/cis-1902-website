import unittest
from src import *


# (all tests must start with 'test')
class TestCar(unittest.TestCase):
    def test_drive_negative_miles(self):
        car = Car("Toyota", "Corolla", 2020)
        with self.assertRaises(ValueError):
            car.drive(-10)

    def test_add_feature(self):
        car_2 = Car("Toyota", "Corolla", 2020, ["Reclining Seats"])
        car_2.add_features("Heated Steering")
        self.assertIn("Reclining Seats", car_2.features)
        self.assertIn("Heated Steering", car_2.features)

    def test_add_features(self):
        car = Car("Toyota", "Corolla", 2020)
        car.add_features("Leather Seats")
        self.assertEqual(car.features, ["Leather Seats"])

        car_2 = Car("Toyota", "Corolla", 2021, ["Reclining Seats"])
        car_2.add_features("Heated Steering")
        self.assertIn("Reclining Seats", car_2.features)
        self.assertIn("Heated Steering", car_2.features)
        self.assertEqual(len(car_2.features), 2)

        car_3 = Car("Toyota", "Corolla", 2020)
        self.assertEqual(len(car_3.features), 0)


if __name__ == "__main__":
    unittest.main()
