from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
cors = CORS(app)
app.config["CORS_HEADERS"] = "Content-Type"


@app.route("/hello_world", methods=["GET"])
def hello_world():
    """
    A simple endpoint that returns 'Hello World'.

    This is used for essentially testing that the server is online and working!

    The HTML site using Ping Server button will access this endpoint or you can navigate to a
    browser and type in the URL to see the response.
    """
    return "Hello World"


@app.route("/get-activities/<int:count>", methods=["GET"])
def get_activities(count):
    """
    Endpoint to fetch a list of activities based on the specified activity type.
    The route parameter 'count' specifies the number of unique activities desired.

    Should return a jsonified list of activities.

    Be sure to set the status code to 200 if the activities are fetched successfully. Use other status codes as you see fit.
    """
    pass


@app.route("/generate-story", methods=["POST"])
def generate_story():
    """
    Endpoint to generate a story based on specified attributes: 'name', 'product_id', and optional 'story_starter' and 'activity_type'.
    The activity_type could contain an activity or an empty string. If this is the case, just generate a completely random activity.
    Otherwise, generate one that is within the specified activity type.

    Use the HTML site and network tab to test and determine the payload. Your output should be around 50-200 words long
    (feel free to do more or less as you see fit).

    Be sure to set the status code to 200 if the story is generated successfully. Use other status codes as you see fit.
    """
    pass


if __name__ == "__main__":
    app.run(debug=True)
