Homework 6: Flask & Requests (& LLMs)

This will be a short homework to get you familiar with Flask and Requests. You will be building a simple web application that will allow you to generate a story using some user-defined parameters. You will also be using a pre-trained language model to generate the story.

There are two parts to this application. The app.py which takes care of all the backend functions that the story_generator.html will interact with and the caller.py, which takes care of making external requests to all the websites.

After Tuesday 04/02, you should be able to complete caller.py. After Tuesday, 04/09, you should be able to complete app.py. Caller.py alone will account for around 80% of the assignment. All 
of story_generator.html is given to you, and you don't have to modify it (unless you want to, of course).

To use the frontend, you can just open your file explorer / file folder and double click on the story_generator.html. Alternatively, you can open a browser and type in the path to the file. Feel free to poke around in the HTML to see what's going on!

Essentially, the goal is to generate a story of what some person may be doing if they are bored. We won't be testing your understanding of prompt engineering and the easiest model to use - GPT2 - is a bit ancient at this point, but your output should be reasonable should be prompted / consistent of the following attributes. 

- The story should be about some person who is bored
- The person is of the specified age as returned by the [Agify API](https://agify.io/). This API allows you to estimate the age of a person based on their name.
- The story should also include some activity. You can get the activity either by directly using the Bored API at https://www.boredapi.com/ or by having the user first specifying an activity type and then using the Bored API to get a random activity of that type. We are going to get the activity types by sampling a bunch of Bored API calls until we get x number of unique activity types (or we reach some certain threshold specified in the function).
- The story will have the person utilizing some Etsy product. However, we may not have the Etsy product but will instead have the Product ID. For example, [this product](https://www.etsy.com/listing/778171534/pastel-blue-beret?click_key=a6cdd38ae33225bb2aaeb90fbcbdb5576fcc4b5b%3A778171534&click_sum=243178e0&ref=stl_listing-2) will have product ID 778171534. However, we want the name of the product. Think about how you may get the name of the product using the product ID only. (As a hint, this will require you to make a request to the /listing/:pid) and then allowing the redirect to take you to a more parseable page. 
- At the end, the user can specify an optional story starter, which you can integrate in whatever way you see fit

Once this is over, you should generate a story using either GPT2, whatever model you like on HuggingFace, or using the [OpenAI API and ChatGPT libraries](https://www.analyticsvidhya.com/blog/2023/05/how-to-use-chatgpt-api-in-python/) (best results). Feel free to do whatever you want here.

You should be able to see your own generated story in the frontend. There are a total of 7 methods to complete between both the caller.py and app.py files. As always, post on Ed or come to office hours if you have any questions.

Below is a sample image. I used GPT4 to generate the story, so don't feel pressured to have an similar output!

[![Sample Image](sample.png)](sample.png)
