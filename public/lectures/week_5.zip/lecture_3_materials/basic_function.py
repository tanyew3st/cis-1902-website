# basic_function.py


def add(a, b):
    """
    Returns the sum of a and b.
    """
    if type(a) not in (int, float) or type(b) not in (int, float):
        raise TypeError("Both arguments must be numbers.")
    return a + b
