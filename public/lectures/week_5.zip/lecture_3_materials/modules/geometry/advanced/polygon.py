def regular_polygon_area(side_length, num_sides):
    from math import tan, pi

    return (num_sides * side_length**2) / (4 * tan(pi / num_sides))
