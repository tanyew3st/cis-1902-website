def area(length, width):
    return length * width


def perimeter(length, width):
    return 2 * (length + width)


__all__ = ["area"]

print("hi im a rectangle")
print(f"my module name is {__name__}")
