import geometry

print(f"{__name__}")
# print(globals())
# print(geometry)
