"""Python Testing Tutorial

To run these tests, save this file and run it with the command:
`python -m unittest <filename>.py`
"""

from math import isclose
import unittest


# Part 1: Basic Test Case
# -----------------------
class TestBasic(unittest.TestCase):
    def test_true(self):
        """A simple test that always passes."""
        self.assertTrue(True)


# Part 2: Setup and Teardown
# ---------------------------
class TestWithSetup(unittest.TestCase):
    def setUp(self):
        """Method to set up test environment before each test method."""
        self.resource = "Resource allocated"
        print("Setup: Resource allocated")

    def tearDown(self):
        """Method to tear down test environment after each test method."""
        print("Teardown: Resource released")
        self.resource = None

    def test_resource(self):
        """Test the resource is allocated properly."""
        self.assertEqual(self.resource, "Resource allocated")


# Part 3: Testing for Exceptions
# ------------------------------
class TestExceptions(unittest.TestCase):
    def test_raise_exception(self):
        """Test that an exception is raised as expected."""
        with self.assertRaises(ValueError):
            raise ValueError("A mock value error.")


# Part 4: More General Testing
# -----------------------------
class TestGeneral(unittest.TestCase):
    def test_equality(self):
        """Test for equality."""
        self.assertEqual(1 + 1, 2)

    def test_in_list(self):
        """Test an item is in a list."""
        self.assertIn(1, [1, 2, 3])

    def test_float_equality(self):
        self.assertTrue(isclose(0.1 + 0.2, 0.3))


if __name__ == "__main__":
    unittest.main()
