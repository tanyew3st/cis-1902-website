# test_basic_function.py

import unittest
from basic_function import add


class TestAddFunction(unittest.TestCase):
    """
    Test case for the add function.
    """

    def test_add_integers(self):
        """
        Test adding two integers.
        """
        self.assertEqual(add(1, 2), 3, "Should be 3")

    def test_add_strings_raises_typeerror(self):
        """
        Test adding two strings raises TypeError.
        """
        with self.assertRaises(TypeError):
            add("a", "b")


if __name__ == "__main__":
    unittest.main()
