# Demonstrating mypy type checking
# Save this script as example.py and run `mypy example.py` in your terminal

from typing import List, Optional


def sum_numbers(numbers: List[int]) -> int:
    if numbers is None:
        return 0
    return sum(numbers)


# Correct usage
total = sum_numbers([1, 2, 3])

# This will raise a type error with mypy due to incorrect type
total = sum_numbers(["one", "two", "three"])
