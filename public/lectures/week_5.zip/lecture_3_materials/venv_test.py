from emoji import emojize

print(emojize(":thumbs_up:"))
